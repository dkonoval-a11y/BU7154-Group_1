# Reconstruction validation

Reference comparison: **PASS**.

Source customers: 14,942. Compared cells: 532,860. Mismatches: 0.

| Section | Rows | Cells | Mismatches | Status |
|---|---:|---:|---:|---|
| BU7141_Data_Transformation.xlsx/AnalysisData/Id | 14942 | 522970 | 0 | PASS |
| Monthly_Membership_Results.xlsx/MonthlyData/MonthStart | 48 | 960 | 0 | PASS |
| Monthly_Membership_Results.xlsx/SeasonalSummary/MonthNumber | 12 | 288 | 0 | PASS |
| Monthly_Membership_Results.xlsx/AnnualSummary/Year | 4 | 60 | 0 | PASS |
| Age_Group_Results.xlsx/MonthlyData/AgeGroup/MonthStart | 96 | 1728 | 0 | PASS |
| Age_Group_Results.xlsx/AnnualSummary/AgeGroup/Year | 8 | 96 | 0 | PASS |
| Age_Group_Results.xlsx/SeasonalComparison/MonthNumber/MonthName | 12 | 192 | 0 | PASS |
| Age_Group_Results.xlsx/YearlyRateGaps/MonthStart/Year | 48 | 576 | 0 | PASS |
| Age_Group_Results.xlsx/FocusWindows/AgeGroup/Year | 16 | 128 | 0 | PASS |
| Age_Group_Results.xlsx/Sensitivity/Scenario/AgeGroup | 8 | 48 | 0 | PASS |
| Retention_Results.xlsx/Summary/Scope/HorizonDays | 18 | 252 | 0 | PASS |
| Retention_Results.xlsx/CohortRetention/CohortMonth/AgeGroup | 192 | 2496 | 0 | PASS |
| Retention_Results.xlsx/CohortComparisons/CohortMonth/CohortYear | 96 | 1440 | 0 | PASS |
| Retention_Results.xlsx/Sensitivity/Scope/HorizonDays | 12 | 168 | 0 | PASS |
| Age_Group_Results.xlsx/GroupsAndChecks/Measure | 10 | 30 | 0 | PASS |
| Age_Group_Results.xlsx/FocusWindows/Year/Window | 8 | 32 | 0 | PASS |
| Age_Group_Results.xlsx/Sensitivity/Scenario/MonthNumber | 48 | 816 | 0 | PASS |
| Monthly_Membership_Results.xlsx/Validation/MonthStart/StockFlowResidual | 48 | 240 | 0 | PASS |
| Monthly_Membership_Results.xlsx/Validation/MonthStart/PrimaryClosingStock | 48 | 192 | 0 | PASS |
| Monthly_Membership_Results.xlsx/Validation/Year/FinishDate | 8 | 32 | 0 | PASS |
| Age_Group_Results.xlsx/age quality counts | 9 | 18 | 0 | PASS |
| Monthly_Membership_Results.xlsx/overview values | 12 | 24 | 0 | PASS |
| Monthly_Membership_Results.xlsx/validation counts | 16 | 32 | 0 | PASS |
| Retention_Results.xlsx/definition check counts | 21 | 42 | 0 | PASS |

Floating-point comparisons allow absolute 1e-10 and relative 1e-12 rounding differences.
The original reference files are retained unchanged. Original source code was unavailable.
See SourceChecks.csv for preserved source-data anomalies; these were not silently corrected.
