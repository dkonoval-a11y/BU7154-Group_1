"""Validation against source semantics and independent Excel reference values."""
from __future__ import annotations

import datetime as dt
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import load_workbook

from .analysis import (ACTIVITIES, CUTOFF, GROUP_A, GROUP_B, MONTHS, START, STOP,
                       age_masks, in_reporting_period)


def source_checks(d: pd.DataFrame) -> pd.DataFrame:
    entries = d.StartDate.ge(START) & d.StartDate.lt(STOP)
    event = d.Dropout.eq(1)
    same_month = d.StartDate.dt.to_period("M").eq(d.FinishDate.dt.to_period("M"))
    report = in_reporting_period(d)
    mid, stable = age_masks(d), age_masks(d,"stable")
    selected = mid[GROUP_A] | mid[GROUP_B]
    boundary = (mid[GROUP_A] & ~stable[GROUP_A]) | (mid[GROUP_B] & ~stable[GROUP_B])
    checks = [
        ("Missing customer IDs",d.Id.isna().sum(),"ERROR"),
        ("Duplicate customer IDs",d.Id.duplicated().sum(),"ERROR"),
        ("Missing or invalid EnrollmentStart",d.StartDate.isna().sum(),"ERROR"),
        ("Missing or invalid EnrollmentFinish",d.FinishDate.isna().sum(),"ERROR"),
        ("Missing essential dates or status",d[["EnrollmentStart","EnrollmentFinish","Dropout"]].isna().any(axis=1).sum(),"ERROR"),
        ("Invalid Dropout coding",(~d.Dropout.isin([0,1])).sum(),"ERROR"),
        ("Finish precedes start",d.EnrollmentFinish.lt(d.EnrollmentStart).sum(),"ERROR"),
        ("Dates beyond source cutoff",(d.StartDate.gt(CUTOFF)|d.FinishDate.gt(CUTOFF)).sum(),"ERROR"),
        ("Uncensored records not at cutoff",(d.Dropout.eq(0)&d.FinishDate.ne(CUTOFF)).sum(),"ERROR"),
        ("Censoring within reporting period",(d.Dropout.eq(0)&d.FinishDate.ge(START)&d.FinishDate.lt(STOP)).sum(),"ERROR"),
        ("Invalid renewal counts",(d.NumberOfRenewals.isna()|d.NumberOfRenewals.lt(0)|d.NumberOfRenewals.mod(1).ne(0)).sum(),"ERROR"),
        ("Invalid activity indicators",(~d[ACTIVITIES].isin([0,1])).sum().sum(),"ERROR"),
        ("Activity count disagrees with flags",d.NumberOfActivities.ne(d[ACTIVITIES].sum(axis=1)).sum(),"ERROR"),
        ("Input records",len(d),"INFO"),
        ("Censored input records",d.Dropout.eq(0).sum(),"INFO"),
        ("Renewed at least once",d.NumberOfRenewals.gt(0).sum(),"INFO"),
        ("Source records",len(d),"INFO"),
        ("Age zero",d.Age.eq(0).sum(),"INFO"),
        ("Missing or nonnumeric age",pd.to_numeric(d.Age,errors="coerce").isna().sum(),"INFO"),
        ("Negative, above-100 or noninteger age",(d.Age.lt(0)|d.Age.gt(100)|d.Age.mod(1).ne(0)).sum(),"INFO"),
        ("Negative estimated entry age among otherwise valid ages",(d.Age.gt(0)&d.EstimatedEntryAge.lt(0)).sum(),"INFO"),
        ("Total unusable/unknown ages",(~d.ValidAge).sum(),"INFO"),
        ("Unusable ages observed in reporting period",(~d.ValidAge&report).sum(),"INFO"),
        ("Usable reporting customers outside the two proposed groups",(d.ValidAge&report&~selected).sum(),"INFO"),
        ("Primary selected reporting customers sensitive to an age boundary",(report&boundary).sum(),"INFO"),
        ("All first entrants 2015-2018",entries.sum(),"INFO"),
        ("Unusable ages among first entrants 2015-2018",(entries&~d.ValidAge).sum(),"INFO"),
        ("Other usable entry ages outside A and B",(entries&d.ValidAge&~selected).sum(),"INFO"),
        ("Selected entrants",(entries&selected).sum(),"INFO"),
        ("Selected age-boundary sensitive entrants",(entries&boundary).sum(),"INFO"),
        ("Selected entrants without potential 180-day follow-up",(entries&selected&(d.StartDate+pd.Timedelta(days=180)).gt(CUTOFF)).sum(),"INFO"),
        ("Final window starts before enrolment",d.LastPeriodStart.lt(d.StartDate).sum(),"REVIEW"),
        ("Final window ends after enrolment",d.LastPeriodFinish.gt(d.FinishDate).sum(),"REVIEW"),
        ("Final window longer than 62 days",(d.LastPeriodFinish-d.LastPeriodStart).dt.days.gt(62).sum(),"REVIEW"),
        ("Stored ratio differs from uncapped actual/allowed by over 0.1 pp",(100*d.RealNumberOfVisits/d.AllowedNumberOfVisitsBySLA-d.Ratio).abs().gt(.1).sum(),"REVIEW"),
    ]
    out = pd.DataFrame(checks,columns=["Check","AffectedRecords","Severity"])
    out["AffectedRecords"] = out.AffectedRecords.astype(int)
    out["Result"] = np.where(out.Severity.eq("ERROR"),np.where(out.AffectedRecords.eq(0),"PASS","FAIL"),out.Severity)
    return out


def monthly_diagnostics(d: pd.DataFrame, m: pd.DataFrame) -> dict[str,pd.DataFrame]:
    rows, snapshots, dates = [], [], []
    event = d.Dropout.eq(1)
    for r in m.itertuples():
        nxt = r.MonthStart + pd.offsets.MonthBegin(1)
        independent = int(d.StartDate.lt(nxt).sum() - (event&d.FinishDate.lt(nxt)).sum())
        rows.append(dict(MonthStart=r.MonthStart,
                         StockFlowResidual=r.ActiveMemberships-r.OpeningMemberships-r.NewEnrolments+r.Dropouts,
                         DropoutPartitionResidual=r.Dropouts-r.DropoutsFromOpening-r.SameMonthEnrolmentDropouts,
                         IndependentLedgerResidual=r.ActiveMemberships-independent,
                         RateResidual=r.DropoutRate-r.DropoutsFromOpening/r.OpeningMemberships))
        last = int((event&d.FinishDate.eq(r.MonthEnd)).sum())
        snapshots.append(dict(MonthStart=r.MonthStart,PrimaryClosingStock=r.ActiveMemberships,
                              DropoutsDatedOnMonthEnd=last,EndDateInclusiveSnapshot=r.ActiveMemberships+last))
    counts = d.loc[event&d.FinishDate.ge(START)&d.FinishDate.lt(STOP)].groupby("FinishDate").size().rename("DropoutsOnDate").reset_index()
    counts["Year"] = counts.FinishDate.dt.year
    for y,g in counts.groupby("Year",sort=True):
        total=g.DropoutsOnDate.sum()
        for r in g.sort_values(["DropoutsOnDate","FinishDate"],ascending=[False,True]).head(2).itertuples():
            dates.append(dict(Year=int(y),FinishDate=r.FinishDate,DropoutsOnDate=r.DropoutsOnDate,
                              ShareOfAnnualDropouts=r.DropoutsOnDate/total))
    annual_counts=m.groupby("Year").NewEnrolments.sum()
    december=m.set_index("MonthStart").ActiveMemberships
    repeated=[name for name,g in m.groupby("MonthName") if g.EnrolmentRateRankWithinYear.le(3).all()]
    repeated=sorted(repeated,key=lambda n:list(__import__("calendar").month_name).index(n))
    overview=pd.DataFrame([
        ("Reporting months",len(m)),
        ("Population interpretation","Observed-cohort interval reconstruction"),
        ("Recorded first enrolments",int(m.NewEnrolments.sum())),
        ("Recorded final dropouts",int(m.Dropouts.sum())),
        ("Same-month entrants/exits",int(m.SameMonthEnrolmentDropouts.sum())),
        ("December 2015 reconstructed stock",int(december.loc["2015-12-01"])),
        ("December 2018 reconstructed stock",int(december.loc["2018-12-01"])),
        ("December-to-December stock change",december.loc["2018-12-01"]/december.loc["2015-12-01"]-1),
        ("2018 versus 2015 first-enrolment change",annual_counts.loc[2018]/annual_counts.loc[2015]-1),
        ("Repeated top-three enrolment months",", ".join(repeated)),
        ("Dropout seasonality","Peaks differ across years"),
        ("Computational validation","All monthly checks pass"),
    ],columns=["Measure","Value"])
    return {"Overview":overview,"MonthlyReconciliation":pd.DataFrame(rows),
            "EndDateSensitivity":pd.DataFrame(snapshots),"LargestExitDates":pd.DataFrame(dates)}


@lru_cache(maxsize=8)
def workbook_rows(path: str) -> dict[str,list]:
    w = load_workbook(path,read_only=True,data_only=True)
    result = {s.title:list(s.values) for s in w}
    w.close()
    return result


def reference_section(path: Path, sheet: str, prefix: list[str]) -> pd.DataFrame:
    """Extract a genuine rectangular section; never use its values in analysis."""
    rows = workbook_rows(str(path.resolve()))[sheet]
    for i,row in enumerate(rows):
        if list(row[:len(prefix)]) == prefix:
            header = list(row)
            while header and header[-1] is None: header.pop()
            body = []
            for r in rows[i+1:]:
                if not r or all(x is None for x in r):break
                body.append(list(r[:len(header)])+[None]*max(0,len(header)-len(r)))
            return pd.DataFrame(body,columns=header)
    raise ValueError(f"Header {prefix!r} not found in {path.name}/{sheet}")


def compare_frames(actual: pd.DataFrame, expected: pd.DataFrame, keys: list[str], name: str
                   ) -> tuple[dict,list[dict]]:
    """Compare all cells, including text/date keys; allow tiny float roundoff."""
    shape_ok = actual.shape == expected.shape and set(actual.columns)==set(expected.columns)
    mismatches = []
    if not shape_ok:
        return dict(Table=name,Status="FAIL",Rows=len(actual),CellsCompared=0,NumericCellsCompared=0,
                    Mismatches=1,Detail=f"Actual {actual.shape}, expected {expected.shape}; columns {list(actual)} vs {list(expected)}"), []
    if keys and (actual.duplicated(keys).any() or expected.duplicated(keys).any()):
        raise ValueError(f"Duplicate comparison keys in {name}: {keys}")
    a=actual.sort_values(keys).reset_index(drop=True) if keys else actual.reset_index(drop=True)
    e=expected.sort_values(keys).reset_index(drop=True) if keys else expected.reset_index(drop=True)
    numbers = 0
    for c in e:
        for i,(av,ev) in enumerate(zip(a[c],e[c])):
            if pd.isna(av) and pd.isna(ev):ok=True
            elif pd.isna(av) or pd.isna(ev):ok=False
            elif isinstance(ev,(dt.datetime,dt.date,pd.Timestamp,np.datetime64)):
                ok=pd.Timestamp(av)==pd.Timestamp(ev)
            elif isinstance(ev,(bool,np.bool_)):
                ok=bool(av)==bool(ev)
            elif isinstance(ev,(int,float,np.integer,np.floating)):
                numbers+=1
                ok=isinstance(av,(int,float,np.integer,np.floating)) and bool(np.isclose(av,ev,rtol=1e-12,atol=1e-10))
            else:ok=str(av)==str(ev)
            if not ok:
                mismatches.append(dict(Table=name,Row=i,Column=c,Actual=str(av),Expected=str(ev)))
    return dict(Table=name,Status="PASS" if not mismatches else "FAIL",Rows=len(a),
                CellsCompared=int(a.size),NumericCellsCompared=numbers,Mismatches=len(mismatches),Detail=""),mismatches


def verify_references(reference_dir: Path, master: pd.DataFrame, monthly: dict,
                      age: dict, retention: dict, checks: pd.DataFrame
                      ) -> tuple[pd.DataFrame,pd.DataFrame]:
    items = [
        ("BU7141_Data_Transformation.xlsx","AnalysisData",["Id"],master,["Id"]),
    ]
    for sn in ("MonthlyData","SeasonalSummary","AnnualSummary"):
        key={"MonthlyData":["MonthStart"],"SeasonalSummary":["MonthNumber"],"AnnualSummary":["Year"]}[sn]
        items.append(("Monthly_Membership_Results.xlsx",sn,[key[0]],monthly[sn],key))
    for sn,key in (("MonthlyData",["AgeGroup","MonthStart"]),("AnnualSummary",["AgeGroup","Year"]),
                   ("SeasonalComparison",["MonthNumber"]),("YearlyRateGaps",["MonthStart"]),
                   ("FocusWindows",["AgeGroup","Year","Window"]),("Sensitivity",["Scenario","AgeGroup"])):
        items.append(("Age_Group_Results.xlsx",sn,list(age[sn].columns[:2]),age[sn],key))
    for sn,key in (("Summary",["Scope","HorizonDays"]),("CohortRetention",["CohortMonth","AgeGroup","HorizonDays"]),
                   ("CohortComparisons",["CohortMonth","HorizonDays"]),("Sensitivity",["Scope","HorizonDays"])):
        items.append(("Retention_Results.xlsx",sn,list(retention[sn].columns[:2]),retention[sn],key))
    extras = [
        ("Age_Group_Results.xlsx","GroupsAndChecks",["Measure"],age["GroupsAndChecks"],["Measure"]),
        ("Age_Group_Results.xlsx","FocusWindows",["Year","Window"],age["FocusWindowGaps"],["Year","Window"]),
        ("Age_Group_Results.xlsx","Sensitivity",["Scenario","MonthNumber"],age["SensitivitySeasonal"],["Scenario","MonthNumber"]),
        ("Monthly_Membership_Results.xlsx","Validation",["MonthStart","StockFlowResidual"],monthly["MonthlyReconciliation"],["MonthStart"]),
        ("Monthly_Membership_Results.xlsx","Validation",["MonthStart","PrimaryClosingStock"],monthly["EndDateSensitivity"],["MonthStart"]),
        ("Monthly_Membership_Results.xlsx","Validation",["Year","FinishDate"],monthly["LargestExitDates"],["Year","FinishDate"]),
    ]
    results, details = [], []
    for fn,sn,prefix,frame,keys in items+extras:
        expected=reference_section(reference_dir/fn,sn,prefix)
        result,bad=compare_frames(frame,expected,keys,f"{fn}/{sn}/{'/'.join(prefix)}")
        results.append(result);details.extend(bad)
    # Numeric validation blocks have descriptive wording that is not regenerated.
    quality=reference_section(reference_dir/"Age_Group_Results.xlsx","GroupsAndChecks",["Check","Records"])
    lookup=checks.set_index("Check").AffectedRecords
    actual=pd.DataFrame({"Check":quality.Check,"Records":[lookup[x] for x in quality.Check]})
    result,bad=compare_frames(actual,quality[["Check","Records"]],["Check"],"Age_Group_Results.xlsx/age quality counts")
    results.append(result);details.extend(bad)
    overview=reference_section(reference_dir/"Monthly_Membership_Results.xlsx","Overview",["Measure","Value"])
    result,bad=compare_frames(monthly["Overview"],overview[["Measure","Value"]],["Measure"],"Monthly_Membership_Results.xlsx/overview values")
    results.append(result);details.extend(bad)
    mv=reference_section(reference_dir/"Monthly_Membership_Results.xlsx","Validation",["Check","AffectedRecords"])
    values=lookup.to_dict()
    values["January 2015 carried-in opening stock"]=int(monthly["MonthlyData"].OpeningMemberships.iloc[0])
    recon=monthly["MonthlyReconciliation"]
    values["Monthly stock-flow and ledger mismatches"]=int(recon[["StockFlowResidual","DropoutPartitionResidual","IndependentLedgerResidual"]].ne(0).any(axis=1).sum())
    values["Rate arithmetic mismatches"]=int(recon.RateResidual.abs().gt(1e-12).sum())
    numeric=mv[pd.to_numeric(mv.AffectedRecords,errors="coerce").notna()]
    missing=set(numeric.Check)-set(values)
    if missing:raise ValueError(f"Unreconstructed monthly check values: {missing}")
    actual=pd.DataFrame({"Check":numeric.Check,"AffectedRecords":[values[x] for x in numeric.Check]})
    result,bad=compare_frames(actual,numeric[["Check","AffectedRecords"]],["Check"],"Monthly_Membership_Results.xlsx/validation counts")
    results.append(result);details.extend(bad)
    # Recompute all numeric entries in the retention Definitions sheet.
    rd=reference_section(reference_dir/"Retention_Results.xlsx","Definitions",["Field or check","Definition or result"])
    numeric=rd[rd["Definition or result"].map(lambda v:isinstance(v,(int,float)) and not isinstance(v,bool))]
    rv={
        "Source customer records":values["Input records"],"Duplicate IDs":values["Duplicate customer IDs"],
        "Missing essential dates or status":values["Missing essential dates or status"],
        "Invalid status codes":values["Invalid Dropout coding"],"End before start":values["Finish precedes start"],
        "Censored ends not at cutoff":values["Uncensored records not at cutoff"],
        "Source unusable or unknown ages":values["Total unusable/unknown ages"],"Source age zero":values["Age zero"],
        "Source missing or nonnumeric age":values["Missing or nonnumeric age"],
        "Source negative, above-100 or noninteger age":values["Negative, above-100 or noninteger age"],
    }
    for c in numeric["Field or check"]:
        if c in values:rv[c]=values[c]
    cohorts=retention["CohortRetention"]
    for h in (90,180):
        q=cohorts[cohorts.HorizonDays.eq(h)]
        rv[f"Excluded for censoring before {h} days"]=int(q.CensoredBeforeHorizon.sum())
    # Exact horizon events are the extra retained records under final-day inclusion.
    base=retention["Summary"].query("Scope == 'All 2015-2018'").set_index("HorizonDays")
    sens=retention["Sensitivity"].query("Scope == 'Final day included'").set_index("HorizonDays")
    for h in (90,180):
        delta=sum((sens.loc[h,"RawRate"+g]-base.loc[h,"RawRate"+g])*base.loc[h,"EligibleN"+g] for g in ("A","B"))
        rv[f"Final exits exactly at day {h}"]=int(round(delta))
    rv["Primary cohorts with either group below 20"]=int(retention["CohortComparisons"].query("HorizonDays == 90").SmallEitherGroup.sum())
    missing=set(numeric["Field or check"])-set(rv)
    if missing:raise ValueError(f"Unreconstructed retention check values: {missing}")
    actual=pd.DataFrame({"Field or check":numeric["Field or check"],"Definition or result":[rv[x] for x in numeric["Field or check"]]})
    result,bad=compare_frames(actual,numeric,["Field or check"],"Retention_Results.xlsx/definition check counts")
    results.append(result);details.extend(bad)
    return pd.DataFrame(results),pd.DataFrame(details,columns=["Table","Row","Column","Actual","Expected"])
